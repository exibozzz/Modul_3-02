<?php


class user{

    public $email;
    public $password;

    public function writeEmailPassword(){
        echo "• Email ulogovanog usera: {$this->email}<br>• Password ulogovanog usera: {$this->password}";
    }

}

$jovana = new user();
$jovana->email = "jovanajovana@gmail.com";
$jovana->password = "jovana12345";

var_dump($jovana->writeEmailPassword());




?>