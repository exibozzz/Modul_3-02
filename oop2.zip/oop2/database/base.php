<?php

    class dbConnect
    {
        public $dbConnection;

        public function __construct(){

            $this->dbConnection = mysqli_connect("localhost", "root", "", "web_shop");
        }


    }