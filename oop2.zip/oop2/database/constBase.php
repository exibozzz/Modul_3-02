<?php

class dbConnect
{
    const HOST = "localhost";

    const USER = "root";

    const DB_PASSWORD = "";

    const DB_NAME = "web_shop";


    public $dbConnection;

    public function __construct()
    {
        $this->dbConnection = mysqli_connect(self::HOST, self::USER, self::DB_PASSWORD, self::DB_NAME);

    }




}